class script(object):
    START_TXT = """👋 Hello {},

നിങ്ങൾക്ക് വേണ്ട മൂവീസ് എനിക്ക് തരാൻ സാധിക്കും 🥳

If you want to request movies use inline search option 🪄

നിങ്ങളുടെ ഗ്രൂപ്പുകളിൽ എന്നെ add ആക്കിയാൽ എനിക്ക് അവിടെയും മൂവി തരാൻ കഴിയും [ Need Admin permission ]😌

Bot Maximum നിങ്ങളുടെ കൂട്ടുകാർക്ക് share ചെയ്യൂ 😎"""

    MY_ABOUT_TXT = """★ Server: <a href=https://www.heroku.com>Heroku</a>
★ Database: <a href=https://www.mongodb.com>MongoDB</a>
★ Language: <a href=https://www.python.org>Python</a>
★ Library: <a href=https://pyrogram.org>Pyrogram</a>"""

    MY_OWNER_TXT = """★ Name: RITHIK VINAYAK 

★ Country: India 🇮🇳"""

    STATUS_TXT = """🗂 Total Files: <code>{}</code>
👤 Total Users: <code>{}</code>
👥 Total Chats: <code>{}</code>
✨ Used Storage: <code>{}</code>
⚡️ Free Storage: <code>{}</code>"""

    NEW_GROUP_TXT = """#NewGroup
★ Title: {}
★ ID: <code>{}</code>
★ Total Members: {}
★ Added by: {}"""

    NEW_USER_TXT = """#NewUser
★ Name: {}
★ ID: <code>{}</code>"""

    NO_RESULT_TXT = """#NoResult
★ Group Name: {}
★ Group ID: <code>{}</code>
★ Name: {}

★ Message: {}"""

    REQUEST_TXT = """★ Name: {}
★ ID: <code>{}</code>

★ Message: {}"""
